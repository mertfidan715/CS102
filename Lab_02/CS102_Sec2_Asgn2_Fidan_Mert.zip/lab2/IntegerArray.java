
import java.util.ArrayList;
public class IntegerArray implements Comparable<IntegerArray>{
    private int[] digits;
    private int numLength;
    private boolean isPositive = true;
    private String number;
    private String absNumber;

    public IntegerArray(String number){
        if (number.charAt(0) == '0'){
            int beginIndex = 0;
            for (int i = 0; i < number.length(); i++){
                if (number.charAt(i) == '0')
                    beginIndex =  i;
            }
            number = number.substring(beginIndex + 1);
        }
        if (number.contains("-")){
            isPositive = false;
            this.numLength = number.length() - 1;
            number = number.substring(1);
            this.number = number;
        }
        this.numLength = number.length();
        this.absNumber = number;
        this.number = number;
        digits = new int[numLength];
        for (int i = 0; i < number.length(); i++){
            if (number.charAt(i) == '0'){
                i++;
            }
            else{
                int digit = Integer.parseInt(number.charAt(i) + "");
                digits[i] = digit;
            }
        }
    }
    public IntegerArray(){
    }
    public int[] getDigits(){
        return this.digits;
    }
    public String getNumber(){
        return this.number;
    }
    public String getAbsNumber(){
        return absNumber;
    }
    public boolean getSign(){
        return this.isPositive;
    }
    public int getNumLength(){
        return this.numLength;
    }
    public int numberOfDigits(){
        return numLength;
    }
    public int MID(){
        return digits[0];
    }
    public int LID(){
        return digits[numLength - 1];
    }
    public int getDigit(int index){
        if (index == 0)
            return this.LID();
        else if (index == numLength - 1)
            return this.MID();
        return digits[index];
    }
    public void setSign(boolean sign){
        this.isPositive = sign;
    }
    public IntegerArray add(IntegerArray other){
        if (this.getSign() != other.getSign()){
             if (this.compareTo(other) == 1)
                 return this.subtract(other);
             else if (this.compareTo(other) == -1)
                 return other.subtract(this);
             return new IntegerArray();
        }
        IntegerArray result;
        IntegerArray max = this;
        IntegerArray min = other;
        if (this.compareTo(other) == -1)
            max = other;
            min = this;
        int l1 = max.getNumLength();
        int l2 = min.getNumLength();
        String number = "";
        String num1;
        String num2;
        if (min.getSign() == false){
            num1 = min.toString().substring(1);
            num2 = "0".repeat(Math.abs(l1-l2)) + max.getNumber();
        }
        else{
            num1 = max.getNumber();
            num2 = "0".repeat(Math.abs(l1-l2)) + min.getNumber();
        }
        ArrayList<Integer> sum = new ArrayList<>();
        for (int i = num1.length()-1; i >= 0; i--){
            sum.add(Integer.parseInt(num1.charAt(i) + "") + Integer.parseInt(num2.charAt(i) + ""));
        }
        for (int i = 0; i < sum.size() - 1; i++){
            if (sum.get(i) >= 10){
                int temp = sum.get(i);
                sum.set(i, temp % 10);
                temp = sum.get(i + 1);
                sum.set(i + 1, temp + 1);
            }
        }
        if (sum.get(sum.size() - 1) >= 10){
            int temp = sum.get(sum.size() - 1);
            sum.set(sum.size() - 1, temp % 10);
            sum.add(1);
        }
        for (int q = sum.size() - 1; q >= 0; q--){
            number += "" + sum.get(q);
        }
        result = new IntegerArray(number);
        if (this.getSign() == false)
            result.setSign(false);
        return result;
    }
    public IntegerArray subtract(IntegerArray other){
        IntegerArray result;
        if (this.getSign() == true && other.getSign() == false){
            IntegerArray a1 = this;
            IntegerArray a2 = new IntegerArray(other.getAbsNumber());
            result = a1.add(a2);
            result.setSign(true);
            return result;
        }
        else if (this.getSign() == false && other.getSign() == true){
            result = this.add(other);
            result.setSign(false);
            return result;
        }
        IntegerArray a1 = this;
        IntegerArray a2 = other;
        int[] arr1 = a1.getDigits();
        int[] arr2 = a2.getDigits();
        int[] diff;
        if (this.getSign() == false){
            diff = new int[a1.getNumLength()];
        }
        else{
            diff = new int[a2.getNumLength()];
        }
        int a = 0;
        int b = arr1.length - 1;
        int c = arr2.length - 1;
        int e = diff.length - 1;
        while (e >= 0){
            int d = 0;
            int a1v = (b >= 0 ? arr1[b] : 0);
            if (arr2[c] + a >= a1v){
                d = arr2[c] + a - a1v;
                a = 0;
            }
            else{
                d = arr2[c] + 10 + a - a1v;
                a = -1;
            }
            diff[e] = d;
            b--;
            c--;
            e--;
        }
        int idx = 0;
        while (idx < diff.length && diff[idx] == 0){
            idx++;
        }
        String number = "";
        for (int q = 0; q < diff.length; q++){
            number += diff[q] + "";
        }
        result = new IntegerArray(number);
        return result;
    }
    public boolean checkEquality(IntegerArray arr2){
        String str1 = this.getAbsNumber();
        String str2 = arr2.getAbsNumber();
        int count = 0;
        for (int i = 0; i < str1.length(); i++){
            if(str1.charAt(i) == str2.charAt(i)){
                count++;
            }
        }
        return (count == str1.length());
    }
    @Override
    public int compareTo(IntegerArray arr){
        int result = 1;
        if (this.getSign() == arr.getSign()){
            if(this.getSign() == true){
                if (this.getNumLength() > arr.getNumLength()) 
                    result = 1;
                else
                    result = -1;
            }
            else if (this.getSign() == false){
                if (this.getNumLength() > arr.getNumLength()) 
                    result = -1;
                else
                    result = 1;
            }
            if (this.getNumLength() == arr.getNumLength() && this.getSign() == true){
                if(this.checkEquality(arr)){
                    return 0;
                }
                else{
                    int count = 0;
                    while (count < this.getNumLength()){
                        if ((Integer.parseInt(this.getAbsNumber().charAt(count) + "") < (Integer.parseInt(arr.getAbsNumber().charAt(count) + "")))){
                            result = -1;
                            return result;
                        }
                        else if ((Integer.parseInt(this.getAbsNumber().charAt(count) + "") > (Integer.parseInt(arr.getAbsNumber().charAt(count) + "")))){
                            result = 1;
                            return result;
                        }
                        else if ((Integer.parseInt(this.getAbsNumber().charAt(count) + "") == (Integer.parseInt(arr.getAbsNumber().charAt(count) + "")))){
                            count++;
                        }
                    }
                }                
            }
        }
        else if (this.getSign() == true && arr.getSign() == false){
            result = 1;
        }else if (this.getSign() == false && arr.getSign() == true){
            result = -1;
        }
        return result;
    }
    public String toString(){
        if(this.getSign())
            return this.getNumber();
        return "-" + this.getNumber();    
    }
}