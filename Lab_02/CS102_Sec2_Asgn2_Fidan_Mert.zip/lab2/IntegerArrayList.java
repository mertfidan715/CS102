import java.util.ArrayList;
public class IntegerArrayList {
    private ArrayList<IntegerArray> numbers = new ArrayList<>();

    public IntegerArrayList(ArrayList<String> numberStr){
        for (int i = 0; i < numberStr.size(); i++){
            String num = numberStr.get(i);
            IntegerArray temp = new IntegerArray(num);
            numbers.add(temp);
        }
    }
    public IntegerArrayList(){
    }
    public int getSize(){
        return numbers.size();
    }
    public IntegerArray getIntegerArrayAt(int index){
        return numbers.get(index);
    }
    public void setIntegerArrayAt(int index, IntegerArray intArr){
        this.numbers.set(index, intArr);
    }
    public void addIntegerArray(String number){
        IntegerArray temp = new IntegerArray(number);
        numbers.add(temp);
    }
    public void removeIntegerArray(int index){
        numbers.remove(index);
    }
    public void removeIntegerArray(IntegerArray intArr){
        if (numbers.contains(intArr))
            numbers.remove(intArr);
    }
    public IntegerArray min(int start, int end){
        IntegerArray min = (this.numbers.get(start));
        for (int i = start; i <= end; i++){
            if (min.compareTo(numbers.get(i)) > 0){
                min = this.numbers.get(i);
            }
        }
        return min;
    }
}
