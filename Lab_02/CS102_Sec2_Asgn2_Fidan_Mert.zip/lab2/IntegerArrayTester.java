import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
public class IntegerArrayTester {
    

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int index;
        String number1 = "-12637813421637812332151234535";
        String number2 = "10000";
        String number3 = "000045672";
        String number4 = "94526";
        IntegerArray num1 = new IntegerArray(number1);
        IntegerArray num2 = new IntegerArray(number2);
        IntegerArray num3 = new IntegerArray(number3);
        IntegerArray num4 = new IntegerArray(number4);
        IntegerArray[] numbers = {num1, num2, num3, num4};
        IntegerArrayList test1 = readIntegerArraysFromFile("Test1.txt");
        IntegerArrayList test2 = readIntegerArraysFromFile("Test2.txt");
        IntegerArrayList test3 = readIntegerArraysFromFile("Test3.txt");

        //End of Part 1
        //From now on, Part 2 tests are implemented
        System.out.print("Please enter the filename: ");
        String fileName = in.nextLine();
        if (fileName.equals("Test1.txt")){//Testing implementations for the file "Test1.txt"
            System.out.println("\n" + "Output:\n" + "\nstart index = 0\nmiddle index = 19\nend index = 38\n" + "\nMinimum of all the numbers:\n" + test1.min(20, 38) + "\nMinimum of the first half:\n" + test1.min(0, 19) + "\nMinimum of the second half:\n" + test1.min(20, 38));
        }
        else if (fileName.equals("Test2.txt")){//Testing implementations for the file "Test1.txt"
          System.out.println("\n" + "Output:\n" + "\nstart index = 0\nmiddle index = 499\nend index = 999\n" + "\nMinimum of all the numbers:\n" + test2.min(0, 999) + "\nMinimum of the first half:\n" + test2.min(0, 499) + "\nMinimum of the second half:\n" + test2.min(500, 999));
        }
        else if (fileName.equals("Test3.txt")){//Testing implementations for the file "Test1.txt"
            System.out.println("\n" + "Output:\n" + "\nstart index = 0\nmiddle index = 2\nend index = 4\n" + "\nMinimum of all the numbers:\n" + test3.min(0, 4) + "\nMinimum of the first half:\n" + test3.min(0, 2) + "\nMinimum of the second half:\n" + test3.min(3, 4));
        }

        //Testing add and subtract methods
        //Assume "this" is smaller than "other" for subtraction
        IntegerArray result1 = num3.add(num4);
        System.out.println("The sum of number3 and number4: " + result1.toString());
        IntegerArray result2 = num1.subtract(num2);
        System.out.println("The subtraction of number1 from number2: " + result2.toString());
        IntegerArray result3 = num4.subtract(num3);
        System.out.println("The subtraction of number3 from number4: " + result3.toString());

        //Testing numberOfDigits() method
        System.out.println("The number of digits for each object is the following: " + num1.numberOfDigits() + ", " + num2.numberOfDigits() + ", " + num3.numberOfDigits());
        
        //Testing the implementation for returning the MID and LID values
        System.out.println("The MID values for each object is the following: " + num1.MID() + ", " + num2.MID() + ", " + num3.MID());
        System.out.println("The LID values for each object is the following: " + num1.LID() + ", " + num2.LID() + ", " + num3.LID());
        
        //Testing getDigit() method
        System.out.println("Please enter the index of the digit you want to get for num1: ");
         index = in.nextInt();
        System.out.println("The digit at index " + index + " is " + num1.getDigit(index));
        
        //Testing the overridden compareTo() method
        System.out.println("Choose two numbers to compare by entering two index  values varying from 0 to 3: ");
        int c1 = in.nextInt();
        int c2 = in.nextInt();
        System.out.println("The result of compareTo() method for your choices: " + numbers[c1].compareTo(numbers[c2]));

        //End of Part 1
        //From now on, Part 2 tests are implemented
        
        // System.out.print("Please enter the filename: ");
        // String fileName = in.nextLine();
        // if (fileName.equals("Test1.txt")){//Testing implementations for the file "Test1.txt"
        //     System.out.println("\n" + "Output:\n" + "\nstart index = 0\nmiddle index = 19\nend index = 38\n" + "\nMinimum of all the numbers:\n" + test1.min(0, 38) + "\nMinimum of the first half:\n" + test1.min(0, 19) + "\nMinimum of the second half:\n" + test1.min(19, 38));
        // }
        // else if (fileName.equals("Test2.txt")){//Testing implementations for the file "Test1.txt"
        //     System.out.println("\n" + "Output:\n" + "\nstart index = 0\nmiddle index = 499\nend index = 999\n" + "\nMinimum of all the numbers:\n" + test2.min(0, 999) + "\nMinimum of the first half:\n" + test2.min(0, 499) + "\nMinimum of the second half:\n" + test2.min(499, 999));
        // }
        // else if (fileName.equals("Test3.txt")){//Testing implementations for the file "Test1.txt"
        //     System.out.println("\n" + "Output:\n" + "\nstart index = 0\nmiddle index = 2\nend index = 4\n" + "\nMinimum of all the numbers:\n" + test3.min(0, 4) + "\nMinimum of the first half:\n" + test1.min(0, 2) + "\nMinimum of the second half:\n" + test1.min(2, 4));
        // }
        
        in.close();
    }

    public static IntegerArrayList readIntegerArraysFromFile(String fileName){
        ArrayList<String> nums = new ArrayList<>();
        try {
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
              String data = myReader.nextLine();
              nums.add(data);
            }
            myReader.close();
          } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        IntegerArrayList result = new IntegerArrayList(nums);
        return result;
    }
}
