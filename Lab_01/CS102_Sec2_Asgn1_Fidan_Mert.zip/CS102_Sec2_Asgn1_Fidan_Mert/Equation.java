public class Equation{

    private int a;
    private int b;
    private int c;

    public Equation(int a, int b, int c){
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public Equation(){

    }

    public int getA(){
        return this.a;
    }

    public int getB(){
        return this.b;
    }

    public int getC(){
        return this.c;
    }

    public void setA(int a){
        this.a = a;
    }

    public void setB(int b){
        this.b = b;
    }

    public void setC(int c){
        this.c = c;
    }

    public void reduceEquation(){
        int result = gcd3(a, b ,c);
        this.a = a / result;
        this.b = b / result;
        this.c = c / result;
    }

    private int gcd(int a, int b){
            if (b == 0){
                return a;
            }
            return gcd(b, a % b);
    }

    private int gcd3(int a, int b, int c){
        int result = gcd(gcd(a, b), c);
        return result;
    }

    public Equation add(Equation eq2){
        Equation result = new Equation();
        result.setA(this.getA() + eq2.getA());
        result.setB(this.getB() + eq2.getB());
        result.setC(this.getC() + eq2.getC());
        result.reduceEquation();
        return result;
    }

    public Equation subtract(Equation eq2){
        Equation result = new Equation();
        result.setA(this.getA() - eq2.getA());
        result.setB(this.getB() - eq2.getB());
        result.setC(this.getC() - eq2.getC());
        result.reduceEquation();
        return result;
    }

    public boolean equals(Equation eq){
        Equation tmp1 = this;
        tmp1.reduceEquation();
        Equation tmp2 = eq;
        tmp2.reduceEquation();
        return tmp1.equals(tmp2);
    }

    public String toString(){
        if (this.getB() == 0){
            return this.getA() + " = " + this.getC();
        }
        else if (this.getC() == 0){
            if (this.getB() != 1){
                return this.getA() + " = " + this.getB() + "x";
            }
            return this.getA() + " = " + "x";
        }  
        else if (this.getB() == 1){
            return this.getA() + " = " + "x" + " + " + this.getC();
        }
        return this.getA() + " = " + this.getB() + "x" + " + " + this.getC();
    }
}