import java.util.Scanner;
public class EquationTester {
   
    
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the value of a, b and c for first equation: ");
        String input1 = in.nextLine();
        String[] equation1 = input1.split(" ");

        System.out.print("Enter the value of a, b and c for second equation: ");
        String input2 = in.nextLine();
        String[] equation2 = input2.split(" ");

        Equation eq1 = new Equation(Integer.parseInt(equation1[0]), Integer.parseInt(equation1[1]), Integer.parseInt(equation1[2]));
        Equation eq2 = new Equation(Integer.parseInt(equation2[0]), Integer.parseInt(equation2[1]), Integer.parseInt(equation2[2]));
        
        //This part is for testing reduceEquation()
        /*System.out.println(eq1.toString());
        eq1.reduceEquation();
        System.out.println(eq1.toString());

        System.out.println(eq2.toString());
        eq2.reduceEquation();
        System.out.println(eq2.toString());*/

        System.out.println("Choose an operation:\n1-) Summation\n2-) Subtraction");
        int choice = in.nextInt();
        if (choice == 1){
           System.out.println("Sum of the equations: " + eq1.add(eq2).toString());
        }
        else{
           System.out.println("Subtraction of the equations: " + eq1.subtract(eq2).toString());
        }

        in.close();
    }
}
