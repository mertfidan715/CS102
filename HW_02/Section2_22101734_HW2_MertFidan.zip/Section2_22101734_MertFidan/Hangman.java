/**
 * This is a basic Hangman Game played on the terminal.
 * @author Ipek Sonmez
 * @author Ahmet Kaan Sever
 * @author Mehmet Hakan Yavuz
 * @date 08.02.2022
 */

public class Hangman{
    
    //Instance variables
    private StringBuffer secretWord = new StringBuffer();
    private StringBuffer allLetters = new StringBuffer();
    private StringBuffer usedLetters = new StringBuffer();
    private int numberOfIncorrectTries;
    private int maxAllowedIncorrectTries;
    private StringBuffer knownSoFar = new StringBuffer();

    public static void main(String[] args) {
        
    }

    //Constructor
    public Hangman()
    {
        maxAllowedIncorrectTries = 6;
        allLetters = new StringBuffer("abcdefghijklmnopqrstuvwxyz");
        chooseSecretWord();
        for(int i = 0; i < secretWord.length(); i++)
        {
            knownSoFar.append("*");
        }
    }

    //Accessor Methods
    public String getAllLetters(){
        return allLetters.toString();
    }

    public String getUsedLetters(){
        return usedLetters.toString();
    }

    public int getNumOfIncorrectTries(){
        return numberOfIncorrectTries;
    }

    public int getMaxAllowedIncorrectTries(){
        return maxAllowedIncorrectTries;
    }

    //Chooses a secret word from the given list
    public void chooseSecretWord() {
        this.secretWord = new StringBuffer();
    
        // This is the fixed word list that the game will use.
        String[] wordList = { "angry",
                              "apple",
                              "brother",
                              "home",
                              "homework",
                              "sister",
                              "street",
                              "truth" };
    
        // Choosing a random word from the word list.
        int ind = (int) (Math.random() * wordList.length);
        this.secretWord.append(wordList[ind]);
    }

    //Returns the number of occurences of the letter in the secret word
    public int tryThis(char letter)
 {
        int counter = 0;
        String letterv1 = "" + letter;
        String letterv2 = letterv1.toLowerCase();
        char letterv3 = letterv2.charAt(0);
        
        for(int i = 0 ; i < secretWord.length() ; i++)
        {
            if( secretWord.charAt(i) == letterv3)
            {
                knownSoFar.replace(i, i+1, "" + letterv3);
                
                counter ++ ;
            }
        }

        if (counter == 0 )
        {
            numberOfIncorrectTries++;
        }

        usedLetters.append(letterv3 + "-");
        return counter;
}

    //Returns the secret word with the correctly guessed letters displayed and other letters appearing blank
    public String getKnownSoFar(){
        return knownSoFar.toString();
    }

    //Checks whether the game is over or not
    public boolean isGameOver(){
        return (hasLost() || getKnownSoFar().equals(secretWord.toString()));
    }

    //Checks whether the player has lost or not
    public boolean hasLost(){
        return (numberOfIncorrectTries > maxAllowedIncorrectTries);
    }
}