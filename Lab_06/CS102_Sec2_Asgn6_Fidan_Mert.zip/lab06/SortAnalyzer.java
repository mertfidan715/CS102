public abstract class SortAnalyzer {
    private int numberOfComparisons;
    protected int k = 3;

    public int getNumberOfComparisons() {
        return numberOfComparisons;
    }
    public void setNumberOfComparisons(int numberOfComparisons) {
        this.numberOfComparisons = numberOfComparisons;
    }

    protected int compare(Comparable o1, Comparable o2) {
        this.numberOfComparisons += 1;
        return o1.compareTo(o2);
    }

    public boolean isSorted(Comparable[] arr) {
        boolean increasingSorted = true;
        boolean decreasingSorted = true;
        for (int i = 0; i < arr.length - 1;) {
            if (increasingSorted || decreasingSorted) {
                int comparison = compare(arr[i], arr[i + 1]);
                if (comparison == 0) {
                    i++;
                } else if (comparison == 1) {
                    decreasingSorted = false;
                    i++;
                } else if (comparison == -1) {
                    increasingSorted = false;
                    i++;
                }
            }
            else{
                i++;
            }
        }
        return (increasingSorted || decreasingSorted);
    }

    public abstract Comparable[] sort(Comparable[] arr);
}
