import java.util.Arrays;
import java.util.Random;

public class RandomArrayGenerator implements ArrayGenerator{
    Random rnd = new Random();

    @Override
    public Integer[] generate(int n) {
        Integer[] result = new Integer[n];
        // return getRandNum(result, n, n);
        return randomArray(result, n);
    }
   
    public Integer[] randomArray(Integer[] res,int n){        
        int zeroCount=0;
        for (Integer i : res) {
            if(i==null){
                zeroCount++;
            }    
        }

        if(zeroCount==0){
            return res;
        }

        Integer randomNumber = rnd.nextInt(n) + 1;

        for (Integer i=0; i<n; i++) {
            if(res[i]==randomNumber){
                return randomArray(res, n);
            }
            if(res[i]==null){
                res[i]=randomNumber;
                return randomArray(res, n);
            } 
        }
        return null;
    }

    public static void main(String[] args) {
        // RandomArrayGenerator generator = new RandomArrayGenerator();
        // DecreasingArrayGenerator generator = new DecreasingArrayGenerator();
        IncreasingArrayGenerator generator = new IncreasingArrayGenerator();
        Integer[] res = generator.generate(8);
        System.out.println(Arrays.toString(res));
    }
}
