public class GeneralizedMergeSortAnalyzer extends SortAnalyzer{

    public void merge(Comparable arr[], int l, int m, int r){
        // Find sizes of two subarrays to be merged
        int n1 = m - l + 1;
        int n2 = r - m;
        /* Create temp arrays */
        int L[] = new int[n1];
        int R[] = new int[n2];
        //Copy data to temp arrays
        for (int i = 0; i < n1; ++i)
            L[i] = (int) arr[l + i];
        for (int j = 0; j < n2; ++j)
            R[j] = (int) arr[m + 1 + j];
  
        /* Merge the temp arrays */
        // Initial indexes of first and second subarrays
        int i = 0, j = 0;
        // Initial index of merged subarray array
        int index = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[index] = L[i];
                i++;
            }
            else {
                arr[index] = R[j];
                j++;
            }
            index++;
        }
        /* Copy remaining elements of L[] if any */
        while (i < n1) {
            arr[index] = L[i];
            i++;
            index++;
        }
        /* Copy remaining elements of R[] if any */
        while (j < n2) {
            arr[index] = R[j];
            j++;
            index++;
        }
    }
  
    // Main function that sorts arr[l..r] using
    // merge()
    @Override
    public Comparable[] sort(Comparable[] arr) {
        int l = 0; 
        double r = arr.length;
        if(r > k){
            int[] pivots = new int[k+1];
            for(int i = 1; i < k; i++){
                pivots[i] = ((i-1) * ((int)r)/k + ((int)(r-1))/k); 
            }
            pivots[0] = 0;
            pivots[k] = (int)(r - 1);
            for(int q = 0; q < k-1; q++){
                Comparable[] subArr = new Comparable[(int)Math.ceil(r/k)];
                l = pivots[q];
                int m = pivots[q+1];
                for(int i = 0; i <= m - l; i++){
                    if(l != pivots[0]){
                        subArr[i] = arr[l+i+1];
                    }
                    else{
                        subArr[i] = arr[l+i];   
                    }
                }
                sort(subArr);
                // Merge the sorted halves
                // merge(arr, l, m, r); 
            }

        }
        else if (r == k){
            int[] pivots = new int[k];
            pivots[0]=l;
            pivots[k]=(int)r-1;
            for(int i = 1; i < k-1; i++){
                pivots[i] = i; 
            }
        }
        else{
            //merge(arr, l, (r-l)/2, r);
        }
        return arr;
    }

    public static void main(String[] args) {
        IncreasingArrayGenerator generator = new IncreasingArrayGenerator();

        Comparable[] test1 = generator.generate(15);

        GeneralizedMergeSortAnalyzer randomAnalyzer = new GeneralizedMergeSortAnalyzer();

        test1 = randomAnalyzer.sort(test1);
        System.out.println(randomAnalyzer.isSorted(test1));
        System.out.println("Random no. of comparisons: "+randomAnalyzer.getNumberOfComparisons());
    }

}