public class MergeSortAnalyzer extends SortAnalyzer {

    @Override
    public Comparable[] sort(Comparable[] arr) {
        mergeSort(arr, 0, arr.length-1);
        return arr;
    }
    public void merge(Comparable arr[], int p, int q, int r) {
        int n1 = q - p + 1;
        int n2 = r - q;
    
        int L[] = new int[n1];
        int M[] = new int[n2];
    
        for (int i = 0; i < n1; i++)
          L[i] = (int)arr[p + i];
        for (int j = 0; j < n2; j++)
          M[j] = (int)arr[q + 1 + j];
    
        int i, j, k;
        i = 0;
        j = 0;
        k = p;
        while (i < n1 && j < n2) {
          if (L[i] <= M[j]) {
            arr[k] = L[i];
            i++;
          } else {
            arr[k] = M[j];
            j++;
          }
          k++;
        }
        while (i < n1) {
          arr[k] = L[i];
          i++;
          k++;
        }
    
        while (j < n2) {
          arr[k] = M[j];
          j++;
          k++;
        }
      }
     public void mergeSort(Comparable arr[], int l, int r) {
        if (l < r) {
          int m = (l + r) / 2;
          mergeSort(arr, l, m);
          mergeSort(arr, m + 1, r);
          merge(arr, l, m, r);
        }
    }
    public static void main(String[] args) {
        RandomArrayGenerator generator = new RandomArrayGenerator();
        IncreasingArrayGenerator increasingGenerator = new IncreasingArrayGenerator();
        DecreasingArrayGenerator decreasingGenerator = new DecreasingArrayGenerator();

        Comparable[] test1 = generator.generate(8);
        Comparable[] test2 = increasingGenerator.generate(8);
        Comparable[] test3 = decreasingGenerator.generate(8);

        MergeSortAnalyzer randomAnalyzer = new MergeSortAnalyzer();
        MergeSortAnalyzer increasingAnalyzer = new MergeSortAnalyzer();
        MergeSortAnalyzer decreasingAnalyzer = new MergeSortAnalyzer();

        test1 = randomAnalyzer.sort(test1);
        System.out.println(randomAnalyzer.isSorted(test1));
        System.out.println("Random no. of comparisons: "+randomAnalyzer.getNumberOfComparisons());

        //test2 = increasingAnalyzer.sort(test2);
        System.out.println(increasingAnalyzer.isSorted(test2));
        System.out.println("Increasing no. of comparisons: "+increasingAnalyzer.getNumberOfComparisons());

        //test3 = decreasingAnalyzer.sort(test3);
        System.out.println(decreasingAnalyzer.isSorted(test3));
        System.out.println("Decrasing no. of comparisons: "+decreasingAnalyzer.getNumberOfComparisons());
    }
}
