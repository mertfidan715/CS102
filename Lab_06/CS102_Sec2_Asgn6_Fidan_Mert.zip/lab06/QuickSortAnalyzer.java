public class QuickSortAnalyzer extends SortAnalyzer{

    @Override
    public Comparable[] sort(Comparable[] arr) {
        // TODO Auto-generated method stub
        return null;
    }
    public static void main(String[] args) {
        IncreasingArrayGenerator generator = new IncreasingArrayGenerator();
        Comparable[] test1 = generator.generate(15);
        QuickSortAnalyzer randomAnalyzer = new QuickSortAnalyzer();

        test1 = randomAnalyzer.sort(test1);
        System.out.println(randomAnalyzer.isSorted(test1));
        System.out.println("Random no. of comparisons: "+randomAnalyzer.getNumberOfComparisons());
    }
    
}
