import java.awt.*;
public interface Movable {
    void move();
    Point getLocation();
}
