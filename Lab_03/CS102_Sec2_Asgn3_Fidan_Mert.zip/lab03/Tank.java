public class Tank extends EnemyVehicle{

    public Tank(int minX, int maxX, int y){
        super(minX, maxX, y);
        this.setPoint((int)Math.floor(Math.random()*(maxX-minX+1)+minX), y);
        this.setHealth(100);
    }
    @Override
    public String getType() {
        return "Tank";
    }
    @Override
    public void move() {
        super.move();
    }
    @Override
    public void takeDamage(double damage) {
        super.takeDamage(damage*0.6);
    }
    @Override
    public String toString() {
        return super.toString();
    }
}
