import java.util.ArrayList;
public class Player {
    
    private final double BOMB_RADIUS = 2.0;
    private final double DAMAGE = 50.0;

    public Player(){
    }
    public void attack(int x, int y, ArrayList<EnemyVehicle> enemies){
        for (EnemyVehicle enemyVehicle : enemies) {
            if(enemyVehicle.getLocation().distance(x, y)<=BOMB_RADIUS){
                enemyVehicle.takeDamage(DAMAGE);
            }
            if(enemyVehicle.getType()=="Helicopter"){
                enemyVehicle.setVehicleSpeed(enemyVehicle.getVehicleSpeed()+1);
            }
            enemyVehicle.move();
        } 
    }
}
