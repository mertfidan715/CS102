public class Game implements Difficulty{
    
    private int difficulty;

    public Game(int difficulty) {
       this.difficulty = difficulty;

    }
    @Override
    public int getDifficulty() {
        return this.difficulty;
    }
    @Override
    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;        
    }
    public EnemyVehicle getNewRandomVehicle() {
        int rand = (int)Math.floor(Math.random()*(2)+1);
        if (this.getDifficulty() == 1){
            if (rand == 1){
                return new Helicopter(0, 5, 20);
            }
            return new Tank(0, 5, 20);
        }
        else if (this.getDifficulty() == 2){
            if (rand == 1){
                return new Helicopter(0, 10, 20);
            }
            return new Tank(0, 10, 20);
        }
        else{
            if (rand == 1){
                return new Helicopter(0, 15, 20);
            }
            return new Tank(0, 15, 20);
        }
    }
}
