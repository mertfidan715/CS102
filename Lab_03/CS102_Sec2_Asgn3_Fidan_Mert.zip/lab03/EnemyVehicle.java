import java.awt.Point;

public abstract class EnemyVehicle implements Movable, Destructible{
    private Point point;
    private final int BASE_SPEED = 3;
    private int vehicleSpeed = BASE_SPEED;
    private double health;

    public EnemyVehicle(int minX, int maxX, int y){
        this.point = new Point((int)Math.floor(Math.random()*(maxX-minX+1)+minX), y);
    }
    public void setPoint(int x, int y){
        this.point = new Point(x, y);
    }
    public int getDistanceToBorder(){
        return (int)Math.hypot(Math.abs(point.getX()), Math.abs(point.getY()));
    }
    public abstract String getType();
    public double getHealth(){
        return this.health;
    }
    public void setHealth(double health) {
        this.health = health;
    }
    public void setVehicleSpeed(int vehicleSpeed) {
        this.vehicleSpeed = vehicleSpeed;
    }
    public int getVehicleSpeed() {
        return vehicleSpeed;
    }
    @Override
    public boolean isDestroyed() {
        if (this.health <= 0.0)
            return true;
        return false;
    }
    @Override
    public void takeDamage(double damage) {
        this.health -= damage;        
    }
    @Override
    public void move() {
       this.point.y-=vehicleSpeed;
    }
    @Override
    public Point getLocation() {
        return this.point;
    }
}
