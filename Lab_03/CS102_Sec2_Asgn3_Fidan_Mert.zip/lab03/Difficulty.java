public interface Difficulty {
    final int EASY = 1;
    final int MEDIUM = 2;
    final int HARD = 3;
    void setDifficulty(int difficulty);
    int getDifficulty();
}
