public class Game{
    private int space;
    private int score;

    public Game(int space, int score){
        this.score = score;
        this.space = space;
    }

    public int getScore() {
        return this.score;
    }

    public int getSpace() {
        return this.space;
    }

    public String toString(){
        return "[" + this.space + "GB" + ", " + this.score + "]";
    }
}
