import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Q2 {
    
    public static void combination(Game[] games, int size, ArrayList<Game> result, int storage, int currentMaxScore) {
        int length = games.length;
        Game combinations[] = new Game[size];
        int[] arr = new int[size];
        int r = 0;
        int i = 0;
        if (size > length){
            return;
        }
        while (r >= 0) {
            if (i <= (length + (r - size))) {
                combinations[r] = games[i];
                arr[r] = i;
                if (r == size - 1) {
                    int sumSpace = 0;
                    int sumScore = 0;
                    for(Game g:combinations){
                        sumSpace+=g.getSpace();
                        sumScore+=g.getScore();
                    }
                    if(sumSpace<=storage && sumScore>currentMaxScore){
                        currentMaxScore=sumScore;
                        result = (ArrayList<Game>) Arrays.asList(combinations);
                        System.out.println(Arrays.toString(combinations) + " " + sumSpace + " " + sumScore);
                    }
                    i++;
                } else {
                    i = arr[r]+1;
                    r++;
                }
            }
            else {
                r--;
                if (r >= 0){
                    i = arr[r]+1;
                }
            }
        }
        if(size==games.length){
            return; 
        }
        combination(games, size+1, result, storage, currentMaxScore);
    }

    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        ArrayList<Game> games = new ArrayList<>();
        games.add(new Game(100, 50));
        games.add(new Game(50, 10));
        games.add(new Game(60, 45));
        Game[] games2 = { new Game(45, 50), new Game(10, 85), new Game(15, 45) };
        System.out.print(Arrays.toString(games.toArray()) + "\nN = ");
        int storage = in.nextInt();
        ArrayList<Game> result = new ArrayList<Game>();
        combination(games2, 1, result, storage, 0);

        in.close();
    }
}
