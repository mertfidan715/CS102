public class Q1{

    public static boolean checkApples(int n, int k, int a){
        if(n == k && a == 0){
            return true;
        }
        else if(n != k && a == 0){
            return false;
        }
        else{
            int diff = n - k;
            int m = (int)Math.ceil(diff / a);
            if (diff <= a * 3 && diff >= a * 2){
                return checkApples(n-m, k, a-1);
            }
            else{
                return false;
            }
        }
    }
    
    public static void main(String[] args) {
        System.out.print(checkApples(74, 30, 16));
    }
}