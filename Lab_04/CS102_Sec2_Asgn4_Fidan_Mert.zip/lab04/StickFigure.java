import java.awt.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class StickFigure{

   private final int MAX_HEIGHT = 600;
   private final int MIN_HEIGHT = 50;
   private Color color;
   private int baseX;
   private int baseY;
   private int size;
   private StickFigurePanel panel;

   public StickFigure(int baseX, int baseY, Color color, int size){
      if (size <= MAX_HEIGHT || size >= MIN_HEIGHT){
         this.size = size;
      }
      this.size = size;
      if (baseX >= size / 8){
         this.baseX = baseX;
      }
      this.baseY = baseY;
      this.color = color;
   }
   public void setX(int baseX){
      this.baseX = baseX;
   }
   public void setY(int baseY){
      this.baseY = baseY;
   }
   public void setPanel(StickFigurePanel panel){
      this.panel = panel;
   }
   public JButton moveButtonCreator(){
      JButton move = new JButton("Move");
      ActionListener listener = new ClickListener();
      move.addActionListener(listener);
      return move;
   }
   
   public static void main (String[] args)
   {
      StickFigure figure = new StickFigure(75, 500, Color.black, 600);
      JFrame frame = new JFrame ("StickFigure");
      frame.setSize(new Dimension(1400, 1000));
      StickFigurePanel panel = new StickFigurePanel(figure.baseX, figure.baseY, figure.color, figure.size);
      frame.getContentPane().add(panel);
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
      figure.setPanel(panel);

      JPanel buttonPanel = new JPanel();
      buttonPanel.add(figure.moveButtonCreator());
      frame.add(buttonPanel, BorderLayout.SOUTH);
   }
   public class ClickListener implements ActionListener{
      public void actionPerformed(ActionEvent event){
         panel.setX(panel.getX() + 10);
         panel.repaint();
      }
   }
}