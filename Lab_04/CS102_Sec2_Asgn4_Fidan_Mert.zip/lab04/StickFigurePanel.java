import javax.swing.*;
import java.awt.*;
public class StickFigurePanel extends JPanel{
    
    private Color color;
    private int baseX;
    private int baseY;
    private int size;

    public StickFigurePanel(int baseX, int baseY, Color color, int size){
        this.color = color;
        this.baseX = baseX;
        this.baseY = baseX;
        this.size = size;
        setBackground(Color.white);
        setFont (new Font("Arial", Font.BOLD, 16));
        setPreferredSize(new Dimension(700, 900));
    }
    public int getX(){
        return this.baseX;
    }
    public void setX(int x){
        this.baseX = x;
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        g.setColor(color);
        g.drawOval(baseX - size / 8, 0, size / 4, size / 4);
        g.drawLine(baseX, size / 4, baseX, size * 3 / 4);

        g.drawLine(baseX, size * 3 / 4, baseX - (size / 8), size);
        g.drawLine(baseX, size * 3 / 4, baseX + (size / 8), size);

        g.drawLine(baseX, size * 3 / 8, baseX - (size / 8), size * 5 / 8);
        g.drawLine(baseX, size * 3 / 8, baseX + (size / 8), size * 5 / 8);

        g.drawOval(baseX - (size / 16), size / 12, size / 40, size / 40);
        g.drawOval(baseX + (size / 16) - (size / 40), size / 12, size / 40, size / 40);
        g.fillOval(baseX - (size / 16), size / 12, size / 40, size / 40);
        g.fillOval(baseX + (size / 16) - (size / 40), size / 12, size / 40, size / 40);

        g.drawLine(baseX - size / 40, size / 12 + (size * 7 / 160), baseX + size / 40, size / 12 + (size * 7 / 160));
        g.drawLine(baseX - size / 40, size / 12 + (size * 7 / 160), baseX, size / 12 + (size * 3 / 40));
        g.drawLine(baseX, size / 12 + (size * 3 / 40), baseX + size / 40, size / 12 + (size * 7 / 160));

        g.drawLine(baseX - (size / 16), size / 12 + (size * 7 / 80), baseX - size / 40, size / 12 + (size * 9 / 80));
        g.drawLine(baseX - size / 40, size / 12 + (size * 9 / 80), baseX + size / 40, size / 12 + (size * 9 / 80));
        g.drawLine(baseX + size / 40, size / 12 + (size * 9 / 80), baseX + (size / 16), size / 12 + (size * 7 / 80));
    }
}
