package cardgame;
import java.util.ArrayList;

// Cardgame
// author: Mert Fidan
// date: 22.02.2022
public class CardGame
{
    // properties
    Cards             fullPack;
    ArrayList<Player> players;
    ScoreCard         scoreCard;
    ScoreCard         roundWinnerScore;
    Cards[]           cardsOnTable;
    int               roundNo;
    int               turnOfPlayer;
    
    // constructors
    public CardGame( Player p1, Player p2, Player p3, Player p4)
    {
        this.turnOfPlayer = 0;
        this.roundNo = 1;
        this.scoreCard = new ScoreCard(4);
        this.roundWinnerScore = new ScoreCard(4);
        this.cardsOnTable = new Cards[4];
        players = new ArrayList<>();
        players.add(p1);
        players.add(p2);
        players.add(p3);
        players.add(p4);
        for (int q = 3; q >= 0; q--) {
			cardsOnTable[q] = new Cards(false);
		}
        fullPack = new Cards(true);
        fullPack.shuffle();
        for (int q = 0; q < 4; q++){
			for (int i = 0; i < 13; i++){
				players.get(q).add(fullPack.getTopCard());
			}
		}
    }
    
    // methods
    public boolean playTurn(Player p, Card c)
    {
        if (this.isGameOver() == false || this.isTurnOf(p) == true){
			roundWinnerScore.update(turnOfPlayer, c.getFaceValue());
			if (turnOfPlayer % 4 == 3){
				for (int i = 0; i < roundWinnerScore.getWinners().length; i++){
					scoreCard.update(i, 1);
				}
                roundNo++;
				turnOfPlayer = 0;
			}else if (turnOfPlayer == 0){
                turnOfPlayer++;
				roundWinnerScore = new ScoreCard(4);
			} else{
				cardsOnTable[turnOfPlayer].addTopCard(c);
				turnOfPlayer++;
			}
			return true;
		}
        else{
            return false;
        }  
    }
    
    public boolean isTurnOf( Player p)
    {
        return (players.indexOf(p) == turnOfPlayer);
    }
    
    public boolean isGameOver()
    {
        if (this.fullPack.getCard().length == cardsOnTable.length)
            return true;
        return false;
    }
    
    public int getScore(int playerNumber)
    {
        return this.scoreCard.getScore(playerNumber);
    }
    
    public String getName(int playerNumber)
    {
        return players.get(playerNumber).getName();
    }
    
    public int getRoundNo()
    {
        return this.roundNo;
    }
    
    public int getTurnOfPlayerNo()
    {
        return this.turnOfPlayer;
    }
    
    public Player[] getWinners()
    {
        int[] test=this.scoreCard.getWinners();
        Player[] winners = new Player[test.length];
        for (int i = 0; i < test.length; i++){
            winners[i] = this.players.get(test[i]);
        }
        return winners;
    }
    
    public String showScoreCard()
    {
        return scoreCard.toString();
    }
    
}