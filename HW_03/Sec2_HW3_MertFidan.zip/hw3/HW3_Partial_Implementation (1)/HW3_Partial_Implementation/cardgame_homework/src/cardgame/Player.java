package cardgame;

// Player - Simple card game player with name and hand of cards
// author: Mert Fidan
// date: 22.02.2022
public class Player
{
    // properties
    String name;
    Cards hand;
    
    // constructors
    public Player(String name)
    {
        this.name = name;
        this.hand = new Cards(false);
    }
    
    // methods
    public String getName()
    {
        return this.name;
    }

    public Cards getHand(){
        return this.hand;
    }
    
    public void add(Card c)
    {
        this.hand.addTopCard(c);
    }
    
    public Card playCard()
    {
        if (hand.cards.length != 0){
            Card playedCard = this.hand.getTopCard();
            return playedCard;
        }
        return null;
    }
    
} // end class Player
