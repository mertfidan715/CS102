import java.util.Scanner;
import cardgame.*;

// CardGameTest
// author: Mert Fidan
// date: 22.02.2022
public class CardGameTest
{
    public static void main( String[] args)
    {
        Scanner scan = new Scanner( System.in);
        
        System.out.println( "Start of CardGameTest\n");
        
        // CONSTANTS
        
        // VARIABLES
        Card       c;
        Cards      cards;
        ScoreCard  scores;
        Player     p;
        CardGame   game;
        
        // PROGRAM CODE
        
        // test Card class
        c = new Card( 0);
        System.out.println( c);
        System.out.println();
        
        // test Cards class
        cards = new Cards( true);
        cards.addTopCard( c);
        cards.testOnlyPrint();  // remove method after testing!
        
        // test ScoreCard class
        scores = new ScoreCard( 4);
        scores.update( 3, 1);
        scores.update( 1, 2);
        System.out.println( "\n" + scores );
        
        // test Player class
        p = new Player("Mert Fidan");
        p.add(new Card(7));
        p.add(new Card(19));
        p.add(new Card(3));
        System.out.println(p.playCard());
        System.out.println(p.playCard());
        System.out.println(p.playCard());
        System.out.println(p.getName());

        
        // test CardGame class too?
        Player p2 = new Player("Emre");
        p2.add(new Card(31));
        Player p3 = new Player("Alper");
        Player p4 = new Player("Kerem");
        game = new CardGame(p, p2, p3, p4);
        c = p2.playCard();
        game.playTurn(p3, c);
        
        // Once you have all the bits working, complete the MyCardGame program
        // that provides a menu allowing any of the players to play their card,
        // an option to see the score card, and one to quit the game at any time.
        // When the game is over it should print out the winners.
        
        System.out.println( "\nEnd of CardGameTest\n" );

        scan.close();
    }
    
} // end of class CardGameTest
