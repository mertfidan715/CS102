package cardgame;

import java.util.ArrayList;
// Cardgame
// author:
// date:
public class CardGame
{
    // properties
    Cards             fullPack;
    ArrayList<Player> players;
    ScoreCard         scoreCard;
    Cards[]           cardsOnTable;
    int               roundNo;
    int               turnOfPlayer;
    
    // constructors
    public CardGame( Player p1, Player p2, Player p3, Player p4)
    {
        // ToDo
    }
    
    // methods
    public boolean playTurn( Player p, Card c)
    {
        // Todo
        return false;
    }
    
    public boolean isTurnOf( Player p)
    {
        // ToDo
        return false;
    }
    
    public boolean isGameOver()
    {
        // ToDo
        return false;
    }
    
    public int getScore( int playerNumber)
    {
        // ToDo
        return -1;
    }
    
    public String getName( int playerNumber)
    {
        // ToDo
        return "Not yet implemented";
    }
    
    public int getRoundNo()
    {
        // ToDo
        return -1;
    }
    
    public int getTurnOfPlayerNo()
    {
        // ToDo
        return -1;
    }
    
    public Player[] getWinners()
    {
        // ToDo
        return null;
    }
    
    public String showScoreCard()
    {
        return scoreCard.toString();
    }
    
}